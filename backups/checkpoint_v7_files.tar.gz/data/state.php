<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'CLP' => 1.0
  ],
  'cacheTimestamp' => 1784967179,
  'microtimeState' => 1784967179.615982,
  'appTimestamp' => 1784957963
];
