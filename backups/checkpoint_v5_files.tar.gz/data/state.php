<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'CLP' => 1.0
  ],
  'cacheTimestamp' => 1784962257,
  'microtimeState' => 1784962257.034937,
  'appTimestamp' => 1784957963
];
