<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'USD' => 1.0
  ],
  'cacheTimestamp' => 1784959533,
  'microtimeState' => 1784959533.205852,
  'appTimestamp' => 1784957963
];
