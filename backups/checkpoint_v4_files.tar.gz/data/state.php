<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'USD' => 1.0
  ],
  'cacheTimestamp' => 1784961285,
  'microtimeState' => 1784961285.989008,
  'appTimestamp' => 1784957963
];
