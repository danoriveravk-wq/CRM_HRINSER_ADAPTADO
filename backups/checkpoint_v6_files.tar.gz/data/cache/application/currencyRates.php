<?php
return (object) [
  'date' => '2026-07-25',
  'rates' => (object) []
];
