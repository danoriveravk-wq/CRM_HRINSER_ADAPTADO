<?php
return (object) [];
