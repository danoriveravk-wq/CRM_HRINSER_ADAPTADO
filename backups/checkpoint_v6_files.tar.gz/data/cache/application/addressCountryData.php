<?php
return [
  'list' => [],
  'preferredList' => []
];
