<?php
return [
  'database' => [
    'host' => 'espocrm-nuevo-db',
    'port' => '',
    'charset' => NULL,
    'dbname' => 'espocrm',
    'user' => 'espocrm',
    'password' => 'db_password_espocrm_123',
    'platform' => 'Mysql'
  ],
  'smtpPassword' => NULL,
  'logger' => [
    'path' => 'data/logs/espo.log',
    'level' => 'WARNING',
    'rotation' => true,
    'maxFileNumber' => 30,
    'printTrace' => false,
    'databaseHandler' => false,
    'sql' => false,
    'sqlFailed' => false
  ],
  'restrictedMode' => false,
  'cleanupAppLog' => true,
  'cleanupAppLogPeriod' => '30 days',
  'webSocketMessager' => 'ZeroMQ',
  'clientSecurityHeadersDisabled' => false,
  'clientCspDisabled' => false,
  'clientCspScriptSourceList' => [
    0 => 'https://maps.googleapis.com'
  ],
  'adminUpgradeDisabled' => false,
  'adminUpgrade' => false,
  'adminExtensionUpload' => true,
  'microtimeInternal' => 1784957965.862733,
  'defaultPermissions' => [
    'dir' => '0755',
    'file' => '0644',
    'user' => 'www-data',
    'group' => 'www-data'
  ],
  'cryptKey' => '8c25fa32382ef88911c05bc2146a357a',
  'actualDatabaseType' => 'mariadb',
  'actualDatabaseVersion' => '12.3.2',
  'instanceId' => 'cf1a6b47-cef6-4770-b713-496036c11d0a',
  'isInstalled' => true
];
