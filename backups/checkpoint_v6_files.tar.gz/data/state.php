<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'CLP' => 1.0
  ],
  'cacheTimestamp' => 1784964298,
  'microtimeState' => 1784964298.873459,
  'appTimestamp' => 1784957963
];
