<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'USD' => 1.0
  ],
  'cacheTimestamp' => 1784959715,
  'microtimeState' => 1784959715.243113,
  'appTimestamp' => 1784957963
];
