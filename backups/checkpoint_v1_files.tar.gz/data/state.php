<?php
return [
  'version' => '10.0.3',
  'currencyRates' => [
    'USD' => 1.0
  ],
  'cacheTimestamp' => 1784958993,
  'microtimeState' => 1784958993.689527,
  'appTimestamp' => 1784957963
];
